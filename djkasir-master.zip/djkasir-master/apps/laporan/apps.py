from django.apps import AppConfig


class LaporanConfig(AppConfig):
    name = 'laporan'
